from django import forms
from .models import User, Complaint, Bin

class AdminRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    user_type = forms.CharField(widget=forms.HiddenInput(), initial='Admin')

    class Meta:
        model = User
        fields = ['username', 'password', 'email']

class AdminLoginForm(forms.Form):
    username = forms.CharField(max_length=50)
    password = forms.CharField(widget=forms.PasswordInput)

class CollectorRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    user_type = forms.CharField(widget=forms.HiddenInput(), initial='Collector')

    class Meta:
        model = User
        fields = ['username', 'password', 'email', 'phone_number']

class CollectorLoginForm(forms.Form):
    username = forms.CharField(max_length=50)
    password = forms.CharField(widget=forms.PasswordInput)

class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    user_type = forms.CharField(widget=forms.HiddenInput(), initial='User')

    class Meta:
        model = User
        fields = ['username', 'password', 'email', 'phone_number', 'pincode']

class UserLoginForm(forms.Form):
    username = forms.CharField(max_length=50)
    password = forms.CharField(widget=forms.PasswordInput)

class ProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'phone_number', 'pincode']

class ComplaintForm(forms.ModelForm):
    bin_id = forms.ModelChoiceField(queryset=Bin.objects.all(), empty_label=None)
    class Meta:
        model = Complaint
        fields = ['details']

class AssignComplaintForm(forms.Form):
    bin = forms.ModelChoiceField(queryset=Bin.objects.all(), empty_label=None)
    collector = forms.ModelChoiceField(queryset=User.objects.filter(user_type='Collector'))

class BinForm(forms.ModelForm):
    class Meta:
        model = Bin
        fields = ['bin_id', 'ward_number', 'pincode']


