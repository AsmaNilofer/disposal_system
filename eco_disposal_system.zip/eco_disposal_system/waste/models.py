from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    user_type = models.CharField(max_length=20)
    phone_number = models.CharField(max_length=15)
    pincode = models.CharField(max_length=10)
    
    def __str__(self):
        return self.username

class Bin(models.Model):
    bin_id = models.CharField(max_length=50, primary_key=True)
    ward_number = models.CharField(max_length=50)
    pincode = models.CharField(max_length=10)
    
    def __str__(self):
        return self.bin_id

class Complaint(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    details = models.TextField()
    status = models.CharField(max_length=50, default='Pending')
    bin = models.ForeignKey(Bin, on_delete=models.CASCADE)
    collector = models.ForeignKey(User, related_name='assigned_complaints', null=True, blank=True, on_delete=models.SET_NULL)  # Add collector field

    def __str__(self):
        return f"Complaint by {self.user.username} on {self.timestamp}"