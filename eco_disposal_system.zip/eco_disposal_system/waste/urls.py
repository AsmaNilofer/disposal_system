from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),

    # Admin URLs
    path('admins/register/', views.register_admin, name='register_admin'),
    path('admins/login/', views.login_admin, name='login_admin'),
    path('admins/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admins/add-collector/', views.add_collector, name='add_collector'),
    path('admins/assign-complaint/', views.assign_complaint, name='assign_complaint'),
    path('admins/view-all-complaints/', views.view_all_complaints, name='view_all_complaints'),
    path('admins/add-bin/', views.add_bin, name='add_bin'),
    path('admins/bin-list/', views.bin_list, name='bin_list'),

    # Collector URLs
    path('collector/login/', views.login_collector, name='login_collector'),
    path('collector/dashboard/', views.collector_dashboard, name='collector_dashboard'),
    path('collector/view-assigned-complaints/', views.view_assigned_complaints, name='view_assigned_complaints'),
    path('collector/change-complaint-status/<int:complaint_id>/', views.change_complaint_status, name='change_complaint_status'),

    # User URLs
    path('user/register/', views.register_user, name='register_user'),
    path('user/login/', views.login_user, name='login_user'),
    path('user/dashboard/', views.user_dashboard, name='user_dashboard'),
    path('user/profile/', views.profile, name='profile'),
    path('user/register-complaint/', views.register_complaint, name='register_complaint'),
    path('user/view-complaint-status/', views.view_user_complaint_status, name='view_complaint_status'),
    path('logout/', views.logout_user, name='logout')
]
