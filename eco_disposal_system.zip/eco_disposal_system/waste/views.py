from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from .forms import AdminRegistrationForm, AdminLoginForm, CollectorRegistrationForm, CollectorLoginForm, UserRegistrationForm, UserLoginForm, ProfileForm, ComplaintForm, BinForm, AssignComplaintForm
from .models import User, Complaint, Bin
from django.contrib.auth.decorators import login_required

def home(request):
    return render(request, 'home.html')

#Admin views

def register_admin(request):
    if request.method == 'POST':
        form = AdminRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.user_type = form.cleaned_data['user_type']
            user.save()
            return redirect('login_admin')  
    else:
        form = AdminRegistrationForm()
    return render(request, 'admin/register_admin.html', {'form': form})

def login_admin(request):
    if request.method == 'POST':
        form = AdminLoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None and user.user_type == 'Admin':
                login(request, user)
                return redirect('admin_dashboard')  # Redirect to admin dashboard after login
            else:
                # Authentication failed or user type is not admin
                return render(request, 'admin/login_admin.html', {'form': form, 'error_message': 'Invalid username, password, or user type'})
    else:
        form = AdminLoginForm()
    return render(request, 'admin/login_admin.html', {'form': form})

@login_required
def admin_dashboard(request):
    return render(request, 'admin/admin_dashboard.html')

@login_required
def add_collector(request):
    if request.method == 'POST':
        form = CollectorRegistrationForm(request.POST)
        if form.is_valid():
            collector = form.save(commit=False)
            collector.set_password(form.cleaned_data['password'])
            collector.user_type = form.cleaned_data['user_type']
            collector.save()
            return redirect('admin_dashboard')  
    else:
        form = CollectorRegistrationForm()
    return render(request, 'collector/register_collector.html', {'form': form})

@login_required
def assign_complaint(request):
    if request.method == 'POST':
        bin_id = request.POST.get('bin_id')
        collector_id = request.POST.get('collector')
        complaint_id = request.POST.get('complaint_id')
        
        complaint = Complaint.objects.get(pk=complaint_id)
        collector = User.objects.get(pk=collector_id)
        bin = Bin.objects.get(pk=bin_id)
        
        complaint.collector = collector
        complaint.bin_id = bin  # Assign the selected bin ID
        complaint.save()
        
        return redirect('admin_dashboard')  # Redirect to admin dashboard after assigning complaint
    else:
        # Retrieve all unassigned complaints
        unassigned_complaints = Complaint.objects.filter(collector__isnull=True)
        collectors = User.objects.filter(user_type='Collector')  # Filter collectors only
        bins = Bin.objects.all()  # Retrieve all bins
        return render(request, 'complaint/assign_complaint.html', {'unassigned_complaints': unassigned_complaints, 'collectors': collectors, 'bins': bins})


@login_required
def view_all_complaints(request):
    all_complaints = Complaint.objects.all()
    return render(request, 'complaint/view_all_complaints.html', {'all_complaints': all_complaints})

def add_bin(request):
    if request.method == 'POST':
        form = BinForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('bin_list')  # Redirect to a view showing the list of bins after adding a new bin
    else:
        form = BinForm()
    return render(request, 'bin/add_bin.html', {'form': form})

def bin_list(request):
    bins = Bin.objects.all()
    return render(request, 'bin/bin_list.html', {'bin_list': bins})

#Collector views 

def login_collector(request):
    if request.method == 'POST':
        form = CollectorLoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user and user.user_type == 'Collector':  # Check user type
                login(request, user)
                return redirect('collector_dashboard')  # Redirect to collector dashboard after login
            else:
                # Authentication failed or user type is not collector
                return render(request, 'collector/login_collector.html', {'form': form, 'error_message': 'Invalid username, password, or user type'})
    else:
        form = CollectorLoginForm()
    return render(request, 'collector/login_collector.html', {'form': form})

@login_required
def collector_dashboard(request):
    return render(request, 'collector/collector_dashboard.html')

@login_required
def view_assigned_complaints(request):
    assigned_complaints = Complaint.objects.filter(collector=request.user)
    return render(request, 'complaint/assigned_complaints.html', {'assigned_complaints': assigned_complaints})


@login_required
def change_complaint_status(request, complaint_id):
    if request.method == 'POST':
        new_status = request.POST.get('status')
        complaint = Complaint.objects.get(pk=complaint_id)
        complaint.status = new_status
        complaint.save()
        return redirect('view_assigned_complaints')  # Redirect to view assigned complaints page
    else:
        complaint = Complaint.objects.get(pk=complaint_id)
        return render(request, 'complaint/change_complaint_status.html', {'complaint': complaint})

#User views

def register_user(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.user_type = form.cleaned_data['user_type']
            user.save()
            return redirect('login_user')  
    else:
        form = UserRegistrationForm()
    return render(request, 'user/register_user.html', {'form': form})

def login_user(request):
    if request.method == 'POST':
        form = UserLoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None and user.user_type == 'User':  # Check user type
                print(user.user_type)
                login(request, user)
                return redirect('user_dashboard')  # Redirect to user dashboard after login
            else:
                # Authentication failed or user type is not user
                return render(request, 'user/login_user.html', {'form': form, 'error_message': 'Invalid username, password, or user type'})
    else:
        form = UserLoginForm()
    return render(request, 'user/login_user.html', {'form': form})

@login_required
def user_dashboard(request):
    return render(request, 'user/user_dashboard.html')

@login_required
def profile(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('profile')  # Redirect to profile page after update
    else:
        form = ProfileForm(instance=request.user)
    return render(request, 'user/profile.html', {'form': form})

@login_required
def register_complaint(request):
    if request.method == 'POST':
        form = ComplaintForm(request.POST)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.user = request.user
            complaint.save()
            return redirect('view_user_complaint_status')  
    else:
        form = ComplaintForm()
    bins = Bin.objects.all()  # Retrieve all bins
    return render(request, 'complaint/register_complaint.html', {'form': form, 'bins': bins})


@login_required
def view_user_complaint_status(request):
    # Retrieve all complaints
    user_complaints = Complaint.objects.filter(user=request.user)

    # Render the template with the complaints
    return render(request, 'complaint/view_complaint_status.html', {'complaints': user_complaints})

def logout_user(request):
    logout(request)
    return redirect('home')  



