from django.apps import AppConfig


class WasteConfig(AppConfig):
    name = 'waste'
